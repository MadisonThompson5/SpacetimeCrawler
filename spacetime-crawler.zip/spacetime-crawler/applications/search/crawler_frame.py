import logging
from datamodel.search.MadisoatPhikhant_datamodel import MadisoatPhikhantLink, OneMadisoatPhikhantUnProcessedLink, add_server_copy, get_downloaded_content
from spacetime.client.IApplication import IApplication
from spacetime.client.declarations import Producer, GetterSetter, Getter, ServerTriggers
from lxml import html,etree
import re, os
from time import time
from uuid import uuid4
import urllib2

from urlparse import urlparse, parse_qs
from uuid import uuid4

max_outlink= ""
min_outlinks = ""
max_links_num = 0
min_links_num= 0
invalid_links= 0
subdomains = dict()

maxLink = 'max_link'
maxCount =    'max_count'
invalidLinks = 'invalid_link'
subdomains = 'subdomains'
minLink = 'min_link'
minCount = 'min_count'
downloadCount = 'download_count'

Data = {
    maxLink: "",
    maxCount: 0,
    invalidLinks: 0,
    subdomains: dict(),
    minLink: "",
    minCount: -1,
    downloadCount: 0
}

logger = logging.getLogger(__name__)
LOG_HEADER = "[CRAWLER]"

@Producer(MadisoatPhikhantLink)
@GetterSetter(OneMadisoatPhikhantUnProcessedLink)
@ServerTriggers(add_server_copy, get_downloaded_content)
class CrawlerFrame(IApplication):

    def __init__(self, frame):
        self.starttime = time()
        self.app_id = "MadisoatPhikhant"
        self.frame = frame


    def initialize(self):
        self.count = 0
        l = MadisoatPhikhantLink("http://www.ics.uci.edu/")
        print l.full_url
        self.frame.add(l)

    def update(self):
        unprocessed_links = self.frame.get(OneMadisoatPhikhantUnProcessedLink)
        if unprocessed_links:
            link = unprocessed_links[0]
            print "Got a link to download:", link.full_url
            downloaded = link.download()
            links = extract_next_links(downloaded)
            for l in links:
                if is_valid(l):
                    self.frame.add(MadisoatPhikhantLink(l))

    def shutdown(self):
        print (
            "Time time spent this session: ",
            time() - self.starttime, " seconds.")
        analytics_file()
    
def extract_next_links(rawDataObj):
    '''
    rawDataObj is an object of type UrlResponse declared at L20-30
    datamodel/search/server_datamodel.py
    the return of this function should be a list of urls in their absolute form
    Validation of link via is_valid function is done later (see line 42).
    It is not required to remove duplicates that have already been downloaded. 
    The frontier takes care of that.
    
    Suggested library: lxml
    '''

    ## create dictiionary of subdomain
    outputLinks = []
    links_to_count = list()

    #check if url is redirected
    if rawDataObj.is_redirected:
        url= rawDataObj.final_url
    else:
        url = rawDataObj.url;

    ##collect data of url
    parsed = urlparse(url)
    global Data
    ##collect subdomains crawled
    if parsed.hostname not in Data[subdomains]:
        Data[subdomains][parsed.hostname] = 1
    else:
        Data[subdomains][parsed.hostname] += 1
    Data[downloadCount] +=1


    ##Check http code OK and no error message
        
    if rawDataObj.http_code == 200 and rawDataObj.error_message == None:
        base_url = urllib2.urlopen(url)
        content = html.fromstring(base_url.read());
        content.make_links_absolute(url)
        links = list(content.iterlinks())
        for  x in links:
             el, at, link, pos= x;
             ##check if link is valid before appending
             if is_valid(link):
                 outputLinks.append(link)
                 links_to_count.append(link)
                 
             else:
                 Data[invalidLinks] +=1
        ##determine min and max of outgoing links for a page
        if len(links_to_count) > Data[maxCount]:
            Data[maxCount] = len(links_to_count)
            Data[maxLink] = url
        elif len(links_to_count) < Data[minCount] or Data[minCount] ==-1:
            Data[minCount] = len(links_to_count)
            Data[minLink] = url
            

    return outputLinks

def analytics_file():
    print( "Writing crawler data to file")
    ##Write data collected to file
    global Data
    with open("Analytics.txt","w") as f:
        f.write('Number of Successful downloads: ' +str(Data[downloadCount]) + '\n')
        f.write('Page with most outgoing links: '+ str(Data[maxLink]) + '\n')
        f.write('# of outgoing links of ' + str(Data[maxLink])+' : '+ str(Data[maxCount]) + "\n")
        f.write("Page with least outgoing links: "+ str(Data[minLink]) + "\n")
        f.write("# of outgoing links of " + str(Data[maxLink])+" : " +str(Data[minCount]) + "\n")
        f.write("Number of Invalid Links: "+ str(Data[invalidLinks]) + "\n")
        f.write(" Subdomains Visited\n")
        
        for subdomain, links in Data[subdomains].iteritems():
            f.write(str(subdomain) + " : " + str(links) + '\n')
            f.write('\n')
        f.close()


def is_valid(url):
    '''
    Function returns True or False based on whether the url has to be
    downloaded or not.
    Robot rules and duplication rules are checked separately.
    This is a great place to filter out crawler traps.
    '''
    parsed = urlparse(url)
    

    ## check for reapeating directories
    path = parsed.path.split("/")
    set_path = set(path)
    if len(set_path) != len(path):
        return False

    ##check for extra directories
    ## used RE from https://support.archive-it.org/hc/en-us/articles/208332963-Modify-your-crawl-scope-with-a-Regular-Expression
    extra_dir= re.match("^.*(/misc|/sites|/all|/themes|/modules|/profiles|/css|/field|/node|/theme){3}.*$" ,parsed.path.lower())
    if extra_dir != None:

        return False
        

    ## check for calenders
    ## used RE from https://support.archive-it.org/hc/en-us/articles/208332963-Modify-your-crawl-scope-with-a-Regular-Expression

    cal= re.match("^.*calendar.*$" ,parsed.path.lower())
    if cal != None:
        return False

    ##check for long messy strings
    ## used RE from https://support.archive-it.org/hc/en-us/articles/208332963-Modify-your-crawl-scope-with-a-Regular-Expression

    long_str= re.match("^.*/[^/]{300,}$" ,parsed.path.lower())
    if long_str != None:
        return False

 
    if parsed.scheme not in set(["http", "https"]):
        return False

    
    try:
        return ".ics.uci.edu" in parsed.hostname \
            and not re.match(".*\.(css|js|bmp|gif|jpe?g|ico" + "|png|tiff?|mid|mp2|mp3|mp4"\
            + "|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf" \
            + "|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso|epub|dll|cnf|tgz|sha1" \
            + "|thmx|mso|arff|rtf|jar|csv"\
            + "|rm|smil|wmv|swf|wma|zip|rar|gz)$", parsed.path.lower())

    except TypeError:
        print ("TypeError for ", parsed)
        return False
    return True






    
